"""
Copyright 2020 William Rochira at York Structural Biology Laboratory
"""

from common import cleanup_all_pdb_redo_dirs

if __name__ == '__main__':
	cleanup_all_pdb_redo_dirs()
